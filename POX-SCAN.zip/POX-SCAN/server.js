const express = require('express');
const multer = require('multer');
const path = require('path');
const app = express();
const port = 3000;

// Konfigurasi Multer untuk menyimpan file gambar yang diunggah
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Simpan file di folder 'uploads/'
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Beri nama file sesuai dengan waktu unggah
  }
});

const upload = multer({ storage: storage });

// Endpoint untuk mengunggah gambar
app.post('/upload', upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.'); // Jika tidak ada file yang diunggah, kirim respon error
  }
  res.send('File uploaded successfully.'); // Jika berhasil, kirim respon sukses
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

// Endpoint untuk mendapatkan hasil analisis
app.get('/analysis', (req, res) => {
    // Di sini Anda bisa menghubungkan ke server machine learning dan meminta hasil analisis
    const analysisResult = {
      type: 'smallpox',
      description: 'The uploaded image is diagnosed as smallpox.'
    };
    // Kirim hasil analisis kembali ke pengguna
    res.json(analysisResult);
  });
  